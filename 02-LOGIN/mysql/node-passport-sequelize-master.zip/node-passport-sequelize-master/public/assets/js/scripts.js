$(document).ready(function(){
  // do something
})